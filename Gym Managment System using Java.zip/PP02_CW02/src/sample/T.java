package sample;

public enum T {
}
